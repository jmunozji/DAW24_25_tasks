---
title: Tareas de DAW 24/25
---

Es este apartado encontraremos las prácticas obligatorias y cheatsheets de cada alumnos del módulo.

Cada alumno creará una carpeta con las iniciales de su nombre y apellidos en mayúsculas, por ejemplo JMJ

Dentro incluirá 2 archivos markdown, uno para la práctica obligatoria 1 y otro para su cheatsheet de esta unidad.